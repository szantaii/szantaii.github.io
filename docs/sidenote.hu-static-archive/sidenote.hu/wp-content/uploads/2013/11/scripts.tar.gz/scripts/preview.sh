#!/bin/bash

quit()
{
	rm -r /dev/shm/preview
	printf "\n"
	exit 0
}

trap quit INT

mkdir /dev/shm/preview

while true
do
	printf "Capturing..."
	
	raspistill \
	--width 2592 \
	--height 1944 \
	--encoding jpg \
	--quality 100 \
	--output /dev/shm/preview/preview.jpg > /dev/null 2>&1
	
	printf " done\n"
	printf "Converting..."
	
	convert \
	/dev/shm/preview/preview.jpg \
	-resize x480 \
	-format png \
	/dev/shm/preview/prev.png > /dev/null 2>&1
	
	printf " done\n"
	printf "Ready to serve..."
	
	cat /dev/shm/preview/prev.png | \
	netcat -l -p 8000 -q 1 > /dev/null 2>&1
	
	printf " served\n"
done

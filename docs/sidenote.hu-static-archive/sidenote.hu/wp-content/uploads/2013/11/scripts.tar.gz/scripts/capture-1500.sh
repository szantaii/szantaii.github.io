#!/bin/bash

nohup raspistill \
--width 2592 \
--height 1944 \
--timeout 86400000 \
--timelapse 1500 \
--encoding jpg \
--quality 100 \
--output /home/pi/capture/%06d.jpg > /dev/null 2>&1 &

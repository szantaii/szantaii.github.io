#!/usr/bin/python-root

import sys
import json

class RecvSendJSON:
	response = {}
	
	def __init__(self):
		self.request = json.load(sys.stdin)
	
	def send_response(self, property, value):
		self.response[str(property)] = value
		sys.stdout.write("Content-Type: application/json")
		sys.stdout.write("\n")
		sys.stdout.write("\n")
		sys.stdout.write(json.dumps(self.response))
		sys.stdout.flush()
		sys.stdout.close()


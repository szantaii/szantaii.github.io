#!/usr/bin/python-root

import os
import sys
import cgi
import json
import signal
import time
import RPi.GPIO as gpio

from recvsendjson import RecvSendJSON
from processlock import ProcessLock

class DCControl:
	# DC motor GPIO pins
	dc_pwm_pin = 18
	dc_direction_pin_1 = 4
	dc_direction_pin_2 = 17
	
	# DC PWM properties
	dc_pwm_frequency = 500
	dc_pwm_duty = 15
	
	# Read request and setup GPIO pins
	def __init__(self, request):
		self.direction = request["direction"]
		gpio.setmode(gpio.BCM)
		gpio.setup(self.dc_pwm_pin, gpio.OUT)
		gpio.setup(self.dc_direction_pin_1, gpio.OUT)
		gpio.setup(self.dc_direction_pin_2, gpio.OUT)
	
	# Start or Stop the DC motor
	def set_dc(self, recv_send_json, process_lock):
		dc_pwm = gpio.PWM(self.dc_pwm_pin, self.dc_pwm_frequency)
		
		# Stop
		if self.direction == "Stop":
			# If there is already a DC motor controller process
			# is running then kill it and stop the motor
			lock_pid = process_lock.get_lock_pid()
			if lock_pid != "":
				os.kill(lock_pid, signal.SIGTERM)
			process_lock.remove_lock()
			process_lock.lock(recv_send_json, "dcControl", False)
			gpio.output(self.dc_direction_pin_1, gpio.HIGH)
			gpio.output(self.dc_direction_pin_2, gpio.LOW)
			dc_pwm.start(0)
			dc_pwm.stop()
			
			recv_send_json.send_response("dcControl", True)
			process_lock.remove_lock()
		else:
			process_lock.lock(recv_send_json, "dcControl", False)
			# Go forwards
			if self.direction == "Forwards":
				gpio.output(self.dc_direction_pin_1, gpio.HIGH)
				gpio.output(self.dc_direction_pin_2, gpio.LOW)
			# Go backwards
			elif self.direction == "Backwards":
				gpio.output(self.dc_direction_pin_1, gpio.LOW)
				gpio.output(self.dc_direction_pin_2, gpio.HIGH)
			
			# Start PWM signal
			dc_pwm.start(self.dc_pwm_duty)
			
			# Send response to client
			recv_send_json.send_response("dcControl", True)
			
			# Wait in infinite loop until killed
			while True:
				time.sleep(0.05)
			
			# Remove lock (this will never happen)
			process_lock.remove_lock()

# Read AJAX POST request
recv_send_json = RecvSendJSON()

# Make a ProcessLock instance using
# "/tmp/dc.lock" as the lock file
dc_lock = ProcessLock("/tmp/dc.lock")

dc_control = DCControl(recv_send_json.request)
dc_control.set_dc(recv_send_json, dc_lock)


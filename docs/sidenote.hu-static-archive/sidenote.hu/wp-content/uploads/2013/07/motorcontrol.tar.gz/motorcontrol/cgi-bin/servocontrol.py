#!/usr/bin/python-root

import os
import sys
import cgi
import json
import signal
import time
import RPi.GPIO as gpio

from recvsendjson import RecvSendJSON
from processlock import ProcessLock

class ServoControl:
	# Servo GPIO pin
	servo_pin = 23
	
	# Servo PWM properties for turning
	servo_pwm_frequency = 50
	servo_pwm_duty_straight = 7.5
	servo_pwm_duty_left = 10
	servo_pwm_duty_right = 5
	servo_sleep_time = 0.5
	
	# Read request and setup the GPIO pin
	def __init__(self, request):
		self.direction = request["direction"]
		gpio.setmode(gpio.BCM)
		gpio.setup(self.servo_pin, gpio.OUT)
	
	# Turn into the requested direction
	def set_servo(self, recv_send_json, process_lock):
		servo_pwm = gpio.PWM(self.servo_pin, self.servo_pwm_frequency)
		
		# Turn straight 
		if self.direction == "Straight":
			# If there is already a a servo control process
			# is running then kill it and turn straight
			lock_pid = process_lock.get_lock_pid()
			if lock_pid != "":
				os.kill(lock_pid, signal.SIGTERM)
			process_lock.remove_lock()
			process_lock.lock(recv_send_json, "servoControl", False)
			
			servo_pwm.start(self.servo_pwm_duty_straight)
		else:
			process_lock.lock(recv_send_json, "servoControl", False)
			# Turn left
			if self.direction == "Left":
				servo_pwm.start(self.servo_pwm_duty_left)
			# Turn right
			elif self.direction == "Right":
				servo_pwm.start(self.servo_pwm_duty_right)
		
		# Wait until the servo turns then stop the PWM signal
		time.sleep(self.servo_sleep_time)
		servo_pwm.stop()
		gpio.setup(self.servo_pin, gpio.IN)
		
		# Send response to client
		recv_send_json.send_response("servoControl", True)
		
		# Remove process lock at the end
		process_lock.remove_lock()

# Read AJAX POST request, and lock
recv_send_json = RecvSendJSON()

# Make an instance of ProcessLock using
# "/tmp/servo.lock" as the lock file
servo_lock = ProcessLock("/tmp/servo.lock")

servo_control = ServoControl(recv_send_json.request)
servo_control.set_servo(recv_send_json, servo_lock)


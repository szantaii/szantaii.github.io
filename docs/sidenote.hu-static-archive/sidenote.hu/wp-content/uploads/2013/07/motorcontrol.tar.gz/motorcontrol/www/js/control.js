var buttonState = {
	pressed : 0,
	notPressed : 1
};

var arrowDirection = {
	forwards : 0,
	backwards : 1,
	left : 2,
	right : 3
}

var UIControl = {
	forwardsArrow : {
		direction : arrowDirection.forwards,
		pressState : buttonState.notPressed
	},
	backwardsArrow : {
		direction : arrowDirection.backwards,
		pressState : buttonState.notPressed
	},
	leftArrow : {
		direction : arrowDirection.left,
		pressState : buttonState.notPressed
	},
	rightArrow : {
		direction : arrowDirection.right,
		pressState : buttonState.notPressed
	},
	
	forwardsKey : {
		pressState : buttonState.notPressed
	},
	backwardsKey : {
		pressState : buttonState.notPressed
	},
	leftKey : {
		pressState : buttonState.notPressed
	},
	rightKey : {
		pressState : buttonState.notPressed
	},
	
	pageOrientation : {
		portrait : {
			normal : 0,
			small : 1
		},
		landscape : {
			normal : 2,
			small : 3
		}
	},
	
	buttonSize : {
		normal : 0,
		small : 1
	},
	
	showErrorMessage : function(){
		$("#wrapper").css({
			"display": "none"
		});
		
		$("#error-wrapper").css({
			"display": "inline"
		});
	},
	
	hideErrorMessage : function(){
		$("#wrapper").css({
			"display": "inline"
		});
		
		$("#error-wrapper").css({
			"display": "none"
		});
	},
	
	insertStreamImage : function(){
		$('#video-stream').prepend('<img src="http://' + location.host + ':8080/?action=stream" />');
	},
	
	toggleArrow : function(arrow){
		switch ( arrow.pressState ) {
			case buttonState.pressed: {
				arrow.pressState = buttonState.notPressed;
				switch ( arrow.direction ) {
					case arrowDirection.forwards: {
						$(".forwards-control").css({
							"background-image": "url(img/arrow_forwards.svg)"
						});
						break;
					}
					case arrowDirection.backwards: {
						$(".backwards-control").css({
							"background-image": "url(img/arrow_backwards.svg)"
						});
						break;
					}
					case arrowDirection.left: {
						$(".left-control").css({
							"background-image": "url(img/arrow_left.svg)"
						});
						break;
					}
					case arrowDirection.right: {
						$(".right-control").css({
							"background-image": "url(img/arrow_right.svg)"
						});
						break;
					}
				}
				break;
			}
			case buttonState.notPressed: {
				arrow.pressState = buttonState.pressed;
				switch ( arrow.direction ) {
					case arrowDirection.forwards: {
						$(".forwards-control").css({
							"background-image": "url(img/arrow_forwards_pressed.svg)"
						});
						break;
					}
					case arrowDirection.backwards: {
						$(".backwards-control").css({
							"background-image": "url(img/arrow_backwards_pressed.svg)"
						});
						break;
					}
					case arrowDirection.left: {
						$(".left-control").css({
							"background-image": "url(img/arrow_left_pressed.svg)"
						});
						break;
					}
					case arrowDirection.right: {
						$(".right-control").css({
							"background-image": "url(img/arrow_right_pressed.svg)"
						});
						break;
					}
				}
				break;
			}
		}
	},
	
	resizeButtons : function(buttonSize){
		if ( buttonSize == UIControl.buttonSize.normal ) {
			$(".left-control").css({
				"height": 150,
				"width": 150,
				"background-size": 150
			});
			
			$(".right-control").css({
				"height": 150,
				"width": 150,
				"background-size": 150
			});
			
			$(".forwards-control").css({
				"height": 150,
				"width": 150,
				"background-size": 150
			});
			
			$(".backwards-control").css({
				"height": 150,
				"width": 150,
				"background-size": 150
			});
		} else {
			$(".left-control").css({
				"height": 100,
				"width": 100,
				"background-size": 100
			});
			
			$(".right-control").css({
				"height": 100,
				"width": 100,
				"background-size": 100
			});
			
			$(".forwards-control").css({
				"height": 100,
				"width": 100,
				"background-size": 100
			});
			
			$(".backwards-control").css({
				"height": 100,
				"width": 100,
				"background-size": 100
			});
		}
	},
	
	changeOrientation : function(pageOrientation){
		switch ( pageOrientation ) {
			case UIControl.pageOrientation.portrait.normal: {
				$("#wrapper").css({
					"width": "494px",
					"height": "684px"
				});
				
				$("#video-frame").css({
					"display": "block"
				});
				
				$("#controls").css({
					"display": "block",
					"margin-left": "0px"
				});
				break;
			}
			case UIControl.pageOrientation.portrait.small: {
				$("#wrapper").css({
					"width": "494px",
					"height": "584px"
				});
				
				$("#video-frame").css({
					"display": "block"
				});
				
				$("#controls").css({
					"display": "block",
					"margin-left": "0px"
				});
				break;
			}
			case UIControl.pageOrientation.landscape.normal: {
				$("#wrapper").css({
					"height": "374px",
					"width": "954px"
				});
				
				$("#video-frame").css({
					"display": "inline-block",
					"vertical-align": "middle"
				});
				
				$("#controls").css({
					"display": "inline-block",
					"vertical-align": "middle",
					"margin-left": "10px"
				});
				break;
			}
			case UIControl.pageOrientation.landscape.small: {
				$("#wrapper").css({
					"height": "380px",
					"width": "804px"
				});
				
				$("#video-frame").css({
					"display": "inline-block",
					"vertical-align": "middle"
				});
				
				$("#controls").css({
					"display": "inline-block",
					"vertical-align": "middle",
					"margin-left": "10px"
				});
				break;
			}
		}
	},
	
	centerElements : function(windowWidth, windowHeight) {
		$("#wrapper").css({
			"left": (windowWidth - $("#wrapper").outerWidth()) / 2 + "px",
			"top": (windowHeight - $("#wrapper").outerHeight()) / 2 + "px"
		});
		
		$("#error-message").css({
			"left": (windowWidth - $("#error-message").outerWidth()) / 2 + "px",
			"top": (windowHeight - $("#error-message").outerHeight()) / 2 + "px"
		});
	},
	
	arrangeElements : function(){
		var windowWidth = $(window).width();
		var windowHeight = $(window).height();
		
		if ( windowWidth >= 514 && windowHeight >= 704 ) {
			UIControl.hideErrorMessage();
			UIControl.changeOrientation(UIControl.pageOrientation.portrait.normal);
			UIControl.resizeButtons(UIControl.buttonSize.normal);
		} else if ( windowWidth >= 514 && windowHeight >= 604 ) {
			UIControl.hideErrorMessage();
			UIControl.changeOrientation(UIControl.pageOrientation.portrait.small);
			UIControl.resizeButtons(UIControl.buttonSize.small);
		} else if ( windowHeight >= 394 && windowHeight < 604 && windowWidth >= 974 ) {
			UIControl.hideErrorMessage();
			UIControl.changeOrientation(UIControl.pageOrientation.landscape.normal);
			UIControl.resizeButtons(UIControl.buttonSize.normal);
		} else if ( windowHeight >= 394 && windowHeight < 604 && windowWidth < 974 && windowWidth >= 824 ) {
			UIControl.hideErrorMessage();
			UIControl.changeOrientation(UIControl.pageOrientation.landscape.small);
			UIControl.resizeButtons(UIControl.buttonSize.small);
		} else {
			UIControl.showErrorMessage();
			MotorControl.init();
		}
		
		UIControl.centerElements(windowWidth, windowHeight);
	}
};

var turnDirection = {
	straight: 0,
	left: 1,
	right: 2
};

var MotorControl = {
	direction: turnDirection.straight,
	
	movementState : {
		stop: 0,
		forwards: 1,
		backwards: 2
	},
	
	motorControlMessage : {
		init : {
			"direction": "Init"
		},
		servo : {
			straight : {
				"direction": "Straight"
			},
			left : {
				"direction": "Left"
			},
			right : {
				"direction": "Right"
			}
		},
		dc:{
			stop : {
				"direction": "Stop"
			},
			forwards : {
				"direction": "Forwards"
			},
			backwards : {
				"direction": "Backwards"
			}
		}
	},
	
	init : function(){
		console.log(MotorControl.motorControlMessage.init);
		
		jQuery.ajax({
			url: "/cgi-bin/motorinit.py",
			type: "post",
			dataType: "json",
			data: JSON.stringify(MotorControl.motorControlMessage.init),
			success: function(response){
				console.log(response);
			},
			error: function(response){
				console.log("Something's fucky.");
				console.log(response);
			},
		});
	},
	
	turn : function(direction){
		switch ( direction ) {
			case turnDirection.straight: {
				jsonData = MotorControl.motorControlMessage.servo.straight;
				break;
			}
			case turnDirection.left: {
				jsonData = MotorControl.motorControlMessage.servo.left;
				break;
			}
			case turnDirection.right: {
				jsonData = MotorControl.motorControlMessage.servo.right;
				break;
			}
		}
		
		console.log(jsonData);
		
		jQuery.ajax({
			url: "/cgi-bin/servocontrol.py",
			type: "post",
			dataType: "json",
			data: JSON.stringify(jsonData),
			success: function(response){
				// ???
				// responseData = jQuery.parseJSON(response);
				// if ( responseData.motorControl == true ) {
				if ( response.servoControl == true ) {
					switch ( jsonData ) {
						case MotorControl.motorControlMessage.servo.straight: {
							if ( UIControl.leftArrow.pressState == buttonState.pressed ) {
								UIControl.toggleArrow(UIControl.leftArrow);
							} else if  ( UIControl.rightArrow.pressState == buttonState.pressed ) {
								UIControl.toggleArrow(UIControl.rightArrow);
							}
							MotorControl.direction = turnDirection.straight;
							break;
						}
						case MotorControl.motorControlMessage.servo.left: {
							if ( UIControl.leftArrow.pressState == buttonState.pressed ) {
								UIControl.toggleArrow(UIControl.leftArrow);
								MotorControl.direction = turnDirection.straight;
							} else if (UIControl.rightArrow.pressState == buttonState.pressed ) {
								UIControl.toggleArrow(UIControl.leftArrow);
								UIControl.toggleArrow(UIControl.rightArrow);
								MotorControl.direction = turnDirection.left;
							} else {
								UIControl.toggleArrow(UIControl.leftArrow);
								MotorControl.direction = turnDirection.left;
							}
							break;
						}
						case MotorControl.motorControlMessage.servo.right: {
							if ( UIControl.rightArrow.pressState == buttonState.pressed ) {
								UIControl.toggleArrow(UIControl.rightArrow);
								MotorControl.direction = turnDirection.straight;
							} else if ( UIControl.leftArrow.pressState == buttonState.pressed ) {
								UIControl.toggleArrow(UIControl.rightArrow);
								UIControl.toggleArrow(UIControl.leftArrow);
								MotorControl.direction = turnDirection.right;
							} else {
								UIControl.toggleArrow(UIControl.rightArrow);
								MotorControl.direction = turnDirection.right;
							}
							break;
						}
					}
				}
				// ??? END
				console.log(response);
			},
			error: function(response){
				console.log("Something's fucky.");
				console.log(response);
			},
		});
	},
	
	go : function(movementState){
		switch ( movementState ) {
			case MotorControl.movementState.stop: {
				jsonData = MotorControl.motorControlMessage.dc.stop;
				break;
			}
			case MotorControl.movementState.forwards: {
				jsonData = MotorControl.motorControlMessage.dc.forwards;
				break;
			}
			case MotorControl.movementState.backwards: {
				jsonData = MotorControl.motorControlMessage.dc.backwards;
				break;
			}
		}
		
		console.log(jsonData);
		
		jQuery.ajax({
			url: "/cgi-bin/dccontrol.py",
			type: "post",
			dataType: "json",
			data: JSON.stringify(jsonData),
			success: function(response){
				console.log(response);
			},
			error: function(response){
				console.log("Something's fucky.");
				console.log(response);
			},
		});
	},
	
	controlListener : function(){
		$(".left-control").click(function(){
			switch ( MotorControl.direction ) {
				case turnDirection.straight: {
					MotorControl.turn(turnDirection.left);
					break;
				}
				case turnDirection.left: {
					MotorControl.turn(turnDirection.straight);
					break;
				}
				case turnDirection.right: {
					MotorControl.turn(turnDirection.left);
					break;
				}
			}
		});
		
		$(".right-control").click(function(){
			switch ( MotorControl.direction ) {
				case turnDirection.straight: {
					MotorControl.turn(turnDirection.right);
					break;
				}
				case turnDirection.left: {
					MotorControl.turn(turnDirection.right);
					break;
				}
				case turnDirection.right: {
					MotorControl.turn(turnDirection.straight);
					break;
				}
			}
		});
		
		$(".forwards-control").mousedown(function(){
			UIControl.toggleArrow(UIControl.forwardsArrow);
			MotorControl.go(MotorControl.movementState.forwards);
		});
		
		$(".forwards-control").mouseup(function(){
			UIControl.toggleArrow(UIControl.forwardsArrow);
			MotorControl.go(MotorControl.movementState.stop);
		});
		
		$(".backwards-control").mousedown(function(){
			UIControl.toggleArrow(UIControl.backwardsArrow);
			MotorControl.go(MotorControl.movementState.backwards);
		});
		
		$(".backwards-control").mouseup(function(){
			UIControl.toggleArrow(UIControl.backwardsArrow);
			MotorControl.go(MotorControl.movementState.stop);
		});
		
		$(document).keydown(function(event){
			switch ( event.keyCode ) {
				case 37: { // left arrow key
					if ( UIControl.leftKey.pressState == buttonState.pressed ) {
						return
					} else {
						UIControl.leftKey.pressState = buttonState.pressed;
						MotorControl.turn(turnDirection.left);
					}
					break;
				}
				case 38: { // forwards arrow key
					if ( UIControl.forwardsKey.pressState == buttonState.pressed ) {
						return
					} else {
						UIControl.forwardsKey.pressState = buttonState.pressed;
						UIControl.toggleArrow(UIControl.forwardsArrow);
						MotorControl.go(MotorControl.movementState.forwards);
					}
					break;
				}
				case 39: { // right arrow key
					if ( UIControl.rightKey.pressState == buttonState.pressed ) {
						return
					} else {
						UIControl.rightKey.pressState = buttonState.pressed;
						MotorControl.turn(turnDirection.right);
					}
					break;
				}
				case 40: { // backwards arrow key
					if ( UIControl.backwardsKey.pressState == buttonState.pressed ) {
						return
					} else {
						UIControl.backwardsKey.pressState = buttonState.pressed;
						UIControl.toggleArrow(UIControl.backwardsArrow);
						MotorControl.go(MotorControl.movementState.backwards);
					}
					break;
				}
			}
		});
		
		$(document).keyup(function(event){
			switch ( event.keyCode ) {
				case 37: { // left arrow key
					UIControl.leftKey.pressState = buttonState.notPressed;
					MotorControl.turn(turnDirection.straight);
					break;
				}
				case 38: { // forwards arrow key
					UIControl.forwardsKey.pressState = buttonState.notPressed;
					UIControl.toggleArrow(UIControl.forwardsArrow);
					MotorControl.go(MotorControl.movementState.stop);
					break;
				}
				case 39: { // right arrow key
					UIControl.rightKey.pressState = buttonState.notPressed;
					MotorControl.turn(turnDirection.straight);
					break;
				}
				case 40: { // backwards arrow key
					UIControl.backwardsKey.pressState = buttonState.notPressed;
					UIControl.toggleArrow(UIControl.backwardsArrow);
					MotorControl.go(MotorControl.movementState.stop);
					break;
				}
			}
		});
	},
};

$(document).ready(function(){
	UIControl.insertStreamImage();
	UIControl.arrangeElements();
	MotorControl.init();
	MotorControl.controlListener();
});

$(window).resize(function(){
	UIControl.arrangeElements();
});

$(window).bind("beforeunload", function(){
	MotorControl.init();
});

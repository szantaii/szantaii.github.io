#!/usr/bin/python-root

import os
import sys
import cgi
import json
import signal
import time
import RPi.GPIO as gpio

from recvsendjson import RecvSendJSON
from processlock import ProcessLock

class MotorInit:
	# DC and servo motor GPIO pins
	dc_pwm_pin = 18
	dc_direction_pin_1 = 4
	dc_direction_pin_2 = 17
	servo_pin = 23
	
	# DC and servo motor PWM properties
	dc_pwm_frequency = 500
	dc_pwm_duty = 0
	servo_pwm_frequency = 50
	servo_pwm_duty_straight = 7.5
	servo_sleep_time = 0.5
	
	# Read request, setup GPIO pins and stop all motors
	def __init__(self, recv_send_json):
		if recv_send_json.request["direction"] == "Init":
			
			# Setup GPIO pins
			gpio.setmode(gpio.BCM)
			gpio.setup(self.dc_pwm_pin, gpio.IN)
			gpio.setup(self.dc_pwm_pin, gpio.OUT)
			gpio.setup(self.dc_direction_pin_1, gpio.IN)
			gpio.setup(self.dc_direction_pin_1, gpio.OUT)
			gpio.setup(self.dc_direction_pin_2, gpio.IN)
			gpio.setup(self.dc_direction_pin_2, gpio.OUT)
			gpio.setup(self.servo_pin, gpio.IN)
			gpio.setup(self.servo_pin, gpio.OUT)
			
			# Turn the servo straight
			servo_pwm = gpio.PWM(self.servo_pin, self.servo_pwm_frequency)
			servo_pwm.start(self.servo_pwm_duty_straight)
			
			# Wait until the servo stops
			time.sleep(self.servo_sleep_time)
			
			# Stop the servo pwm signal
			servo_pwm.stop()
			
			gpio.cleanup()
			
			# Send response to client
			recv_send_json.send_response("motorInit", True)

# Read AJAX POST request, remove locks if any, add locks for init
recv_send_json = RecvSendJSON()

# Make a ProcessLock instance using
# "/tmp/servo.lock" as the lock file
servo_lock = ProcessLock("/tmp/servo.lock")

# Make a ProcessLock instance using
# "/tmp/dc.lock" as the lock file
dc_lock = ProcessLock("/tmp/dc.lock")

# If there is a servo or DC motor
# controller script running then stop them
servo_lock_pid = servo_lock.get_lock_pid()
dc_lock_pid = dc_lock.get_lock_pid()
if servo_lock_pid != "":
	os.kill(servo_lock_pid, signal.SIGTERM)
if dc_lock_pid != "":
	os.kill(dc_lock_pid, signal.SIGTERM)

# Remove the locks of the terminated processes
servo_lock.remove_lock()
dc_lock.remove_lock()

# Place locks
servo_lock.lock(recv_send_json, "motorInit", False)
dc_lock.lock(recv_send_json, "motorInit", False)

# Initialize
motor_init = MotorInit(recv_send_json)

# Remove locks at the end
servo_lock.remove_lock()
dc_lock.remove_lock()


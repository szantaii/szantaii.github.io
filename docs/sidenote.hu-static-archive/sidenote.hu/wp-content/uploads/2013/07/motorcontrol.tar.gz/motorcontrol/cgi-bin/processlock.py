#!/usr/bin/python-root

import os
import sys

class ProcessLock:
	
	def __init__(self, lock_file):
		self.lock_file = lock_file
	
	# Check if the file specified in __init__ exists
	# If it exists then send a lock message to the client
	# Else create the file, and write the PID into it
	def lock(self, recv_send_json, property, value):
		self.pid = str(os.getpid())
		
		if os.path.isfile(self.lock_file):
			recv_send_json.send_response(property, value)
			sys.exit()
		else:
			fd = open(self.lock_file, "w")
			fd.write(self.pid)
			# fd.flush()
			fd.close()
	
	# Return the PID from the lock file if there is any
	# If there is no lock file specififed in self.lock_file
	# return an empty string 
	def get_lock_pid(self):
		if os.path.isfile(self.lock_file):
			fd = open(self.lock_file, "r")
			lock_pid = fd.read()
			fd.close()
			return int(lock_pid)
		else:
			return ""
	
	# Delete the lock file
	def remove_lock(self):
		if os.path.isfile(self.lock_file):
			os.unlink(self.lock_file)


#!/bin/bash
#
# Font image maker script written by szantaii at 2010. September 24.
# 
# This script will generate images from all the truetype and opentype fonts
# contained by the given directory and all of its subdirectories.
#
# Feel free to use this little script for whatever you want. Of course this
# script can be expanded/extended modified in a lot of ways.
#
# Usage:
#     fontscreenshot /usr/share/fonts/
#
#
# If you find any errors or have an idea contact me at szantaii@sidenote.hu
# 

which fontimage > /dev/null

if [[ $? != 0 ]]
then
	echo "The fontimage program is needed to generate screenshots from fonts.
fontimage can be found either in the fontforge or in the fontforge-nox packages.
Or fontimage is not contained by your PATH enviroment variable."
	exit 1
fi

# fontscreenshot < directory >
function fontscreenshot()
{
	
	local DEFAULT_DIRECTORY="/usr/share/fonts/"
	
	local DIRECTORY=${1:-$DEFAULT_DIRECTORY}
	
	local FILE=""
	
	if [[ "$DIRECTORY" != */ ]]
	then
		DIRECTORY="${DIRECTORY}/"
	fi
	
	find "$DIRECTORY" -regex ".*\(otf\|ttf\)$" | while read FILE;
	do
		fontimage $FILE 2> /dev/null # error messages redirected to the void
	done
}

fontscreenshot $1


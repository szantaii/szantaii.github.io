#!/bin/bash

echo Stopping overkill-start.sh, overkill-server \& $2 bot\(s\) in 1 second
echo \(press Ctrl+C to stop shutdown\)
for i in `seq 1 80` ;
do
	sleep 0.0125
	echo -n .
done
killall overkill-start.sh
if [ $? -eq 0 ]
then
	echo "overkill-start.sh killed"
fi
killall overkill-bot
if [ $? -eq 0 ]
then
	echo "overkill-bot(s) killed"
fi
killall overkill-server
if [ $? -eq 0 ]
then
	echo "overkill-server killed"
fi

exit 0


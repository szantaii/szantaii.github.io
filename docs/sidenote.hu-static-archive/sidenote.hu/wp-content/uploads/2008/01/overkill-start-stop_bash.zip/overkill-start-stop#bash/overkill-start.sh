#!/bin/bash

#overkill-start.sh 2007-09-21
#
#script usage:
#				./overkill-start.sh <port> <number of bots>
#
#	example:	./overkill-start.sh 6666 5
#
#do not modify anything under this line
#--------------------------------------

if [ $# -ne 2 ] ;
then
	echo "This script needs 2 arguments: ./overkill-start.sh <port> <number of bots>"
	exit 0
else
	echo Starting overkill-server \& $2 bot\(s\) in 1 second \(press Ctrl+C to stop startup\)
	for i in `seq 1 80` ;
	do
		sleep 0.0125
		echo -n .
	done
	overkill-server -n -p $1 &
	if [ $2 -ne 0 ] ;
	then
		for i in `seq 1 $2` ;
		do
			overkill-bot -a 127.0.0.1 -p $1 &
		done
		while [ 1 ] ; 
		do
			sleep 3
			ps -C overkill-server
			if [ $? -eq 0 ] ;
			then
				ps -C overkill-bot
				if [ $? -ne 0 ] ;
				then
					for i in `seq 1 $2` ;
					do
						overkill-bot -a 127.0.0.1 -p $1 &
					done
				fi
			else
				killall overkill-bot
				sleep 1
				overkill-server -n -p $1 &
			fi
		done
	else
		while [ 1 ] ;
		do
			sleep 3
			ps -C overkill-server
			if [ $? -ne 0 ] ;
			then
				overkill-server -n -p $1 &
			fi
		done
	fi
fi


exit 0

